package notassoft.capa3_dominio;

public class AsignacionCurso {

    // Atributos
    private int codAsignacion;
    private Docente docente;
    private Curso curso;
    private Aula aula;
    private Turno turno;
    private Semestre semestre;
    private int estado;

    public AsignacionCurso() {
    }

    public AsignacionCurso(Curso curso, Semestre semestre) {
        this.curso = curso;
        this.semestre = semestre;
    }

    // Metodos
    public int getCodAsignacion() {
        return codAsignacion;
    }

    public void setCodAsignacion(int codAsignacion) {
        this.codAsignacion = codAsignacion;
    }

    public Docente getDocente() {
        return docente;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public Aula getAula() {
        return aula;
    }

    public void setAula(Aula aula) {
        this.aula = aula;
    }

    public Turno getTurno() {
        return turno;
    }

    public void setTurno(Turno turno) {
        this.turno = turno;
    }

    public Semestre getSemestre() {
        return semestre;
    }

    public void setSemestre(Semestre semestre) {
        this.semestre = semestre;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

}
