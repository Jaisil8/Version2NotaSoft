package notassoft.capa3_dominio;

import javax.swing.table.DefaultTableModel;

public class CustomTableModel extends DefaultTableModel {

    @Override
    public boolean isCellEditable(int row, int column) {
        // Permitir la edición de las celdas de las columnas de nota (2, 3, 4)
        return column >= 2 && column <= 4;
    }
}
