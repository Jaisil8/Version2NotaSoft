package notassoft.capa3_dominio;

import java.util.Date;

public class Semestre {

    // Atributos de clase
    private int codSemestre;
    private String anio;
    private String numeroPeriodo;
    private String periodo;
    private Date fechaInicioSemestre;
    private Date fechaFinSemestre;
    private int estado;

    // Constructores
    public Semestre() {
    }

    public Semestre(int codSemestre, String anio, String numeroPeriodo, String periodo, Date fechaInicioSemestre, Date fechaFinSemestre, int estado) {
        this.codSemestre = codSemestre;
        this.anio = anio;
        this.numeroPeriodo = numeroPeriodo;
        this.periodo = periodo;
        this.fechaInicioSemestre = fechaInicioSemestre;
        this.fechaFinSemestre = fechaFinSemestre;
        this.estado = estado;
    }

    public Semestre(int codSemestre, String periodo) {
        this.codSemestre = codSemestre;
        this.periodo = periodo;
    }

    // Metodos 
    public int getCodSemestre() {
        return codSemestre;
    }

    public void setCodSemestre(int codSemestre) {
        this.codSemestre = codSemestre;
    }

    public String getAnio() {
        return anio;
    }

    public void setAnio(String anio) {
        this.anio = anio;
    }

    public String getNumeroPeriodo() {
        return numeroPeriodo;
    }

    public void setNumeroPeriodo(String numeroPeriodo) {
        this.numeroPeriodo = numeroPeriodo;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public Date getFechaInicioSemestre() {
        return fechaInicioSemestre;
    }

    public void setFechaInicioSemestre(Date fechaInicioSemestre) {
        this.fechaInicioSemestre = fechaInicioSemestre;
    }

    public Date getFechaFinSemestre() {
        return fechaFinSemestre;
    }

    public void setFechaFinSemestre(Date fechaFinSemestre) {
        this.fechaFinSemestre = fechaFinSemestre;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

   
}
