package notassoft.capa3_dominio;

public class Matricula {

    // Atributos
    private int idMatricula;
    private String codMatricula;
    private Alumno alumno;

    // Constructores
    public Matricula() {
    }

    public Matricula(int idMatricula, String codMatricula, Alumno alumno) {
        this.idMatricula = idMatricula;
        this.codMatricula = codMatricula;
        this.alumno = alumno;
    }

    // Metodos
    public int getIdMatricula() {
        return idMatricula;
    }

    public void setIdMatricula(int idMatricula) {
        this.idMatricula = idMatricula;
    }

    public String getCodMatricula() {
        return codMatricula;
    }

    public void setCodMatricula(String codMatricula) {
        this.codMatricula = codMatricula;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

}
