package notassoft.capa3_dominio;

public class Curso extends Ciclo{

    // Atributos de clase
    private int codCurso;
    private String nombreCurso;
    private Ciclo ciclo;

    // Constructores
    public Curso() {
    }

    public Curso(int codCurso, String nombreCurso, Ciclo ciclo) {
        this.codCurso = codCurso;
        this.nombreCurso = nombreCurso;
        this.ciclo = ciclo;
    }
    

    public Curso(int codCurso, String nombreCurso) {
        this.codCurso = codCurso;
        this.nombreCurso = nombreCurso;
    }

    public Curso(String nombreCiclo) {
        super(nombreCiclo);
    }

    

    // Metodos
    public int getCodCurso() {
        return codCurso;
    }

    public void setCodCurso(int codCurso) {
        this.codCurso = codCurso;
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public Ciclo getCiclo() {
        return ciclo;
    }

    public void setCiclo(Ciclo ciclo) {
        this.ciclo = ciclo;
    }

}
