package notassoft.capa3_dominio;

public class Turno {

    // Atributos de clase
    private int codTurno;
    private String nombreTurno;
    private String horario;

    // Constructores
    public Turno() {
    }

    public Turno(int codTurno, String nombreTurno, String horario) {
        this.codTurno = codTurno;
        this.nombreTurno = nombreTurno;
        this.horario = horario;
    }

    // Metodos 
    public int getCodTurno() {
        return codTurno;
    }

    public void setCodTurno(int codTurno) {
        this.codTurno = codTurno;
    }

    public String getNombreTurno() {
        return nombreTurno;
    }

    public void setNombreTurno(String nombreTurno) {
        this.nombreTurno = nombreTurno;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

}
