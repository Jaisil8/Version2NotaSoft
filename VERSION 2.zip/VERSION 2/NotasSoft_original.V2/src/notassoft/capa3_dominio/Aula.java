package notassoft.capa3_dominio;

public class Aula {

    // Atributos de clase
    private int codAula;
    private String numeroAula;
    private String pabellon;
    private String piso;

    // Constructores
    public Aula() {
    }

    public Aula(int codAula, String numeroAula, String pabellon, String piso) {
        this.codAula = codAula;
        this.numeroAula = numeroAula;
        this.pabellon = pabellon;
        this.piso = piso;
    }

 

    // Metodos
    public int getCodAula() {
        return codAula;
    }

    public void setCodAula(int codAula) {
        this.codAula = codAula;
    }

    public String getNumeroAula() {
        return numeroAula;
    }

    public void setNumeroAula(String numeroAula) {
        this.numeroAula = numeroAula;
    }


    public String getPabellon() {
        return pabellon;
    }

    public void setPabellon(String pabellon) {
        this.pabellon = pabellon;
    }

    public String getPiso() {
        return piso;
    }

    public void setPiso(String piso) {
        this.piso = piso;
    }

}
