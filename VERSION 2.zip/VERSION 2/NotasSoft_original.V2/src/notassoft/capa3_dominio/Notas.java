package notassoft.capa3_dominio;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Calendar;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Notas implements Serializable {

    // Atributos
    private double notaPractica;
    private double notaProyecto;
    private double notaExamen;
    private AsignacionCurso asignacionCurso;
    private Matricula matricula;
    private Unidad unidad;

    // Constructores
    public Notas() {
    }

    public Notas(double notaPractica, double notaProyecto, double notaExamen, AsignacionCurso asignacionCurso, Matricula matricula, Unidad unidad) {
        this.notaPractica = notaPractica;
        this.notaProyecto = notaProyecto;
        this.notaExamen = notaExamen;
        this.asignacionCurso = asignacionCurso;
        this.matricula = matricula;
        this.unidad = unidad;
    }

    public Notas(double notaPractica, double notaProyecto, double notaExamen) {
        this.notaPractica = notaPractica;
        this.notaProyecto = notaProyecto;
        this.notaExamen = notaExamen;
    }

    // Metodos
    public Matricula getMatricula() {
        return matricula;
    }

    public void setMatricula(Matricula matricula) {
        this.matricula = matricula;
    }

    public Unidad getUnidad() {
        return unidad;
    }

    public void setUnidad(Unidad unidad) {
        this.unidad = unidad;
    }

    public AsignacionCurso getAsignacionCurso() {
        return asignacionCurso;
    }

    public void setAsignacionCurso(AsignacionCurso asignacionCurso) {
        this.asignacionCurso = asignacionCurso;
    }

    public double getNotaPractica() {
        return notaPractica;
    }

    public void setNotaPractica(double notaPractica) {
        this.notaPractica = notaPractica;
    }

    public double getNotaProyecto() {
        return notaProyecto;
    }

    public void setNotaProyecto(double notaProyecto) {
        this.notaProyecto = notaProyecto;
    }

    public double getNotaExamen() {
        return notaExamen;
    }

    public void setNotaExamen(double notaExamen) {
        this.notaExamen = notaExamen;
    }

    public boolean validarNotasEnRango() {
        return notaPractica >= 0 && notaPractica <= 20
                && notaProyecto >= 0 && notaProyecto <= 20
                && notaExamen >= 0 && notaExamen <= 20;
    }

    public boolean validarNumeros(String texto) {
        Pattern pat = Pattern.compile("^\\d+(\\.\\d+)?$");
        Matcher mat = pat.matcher(texto);
        return mat.matches();
    }

    public boolean tieneFechaLimiteDelIngresoDeNotasValida() {
        if (unidad != null) {
            LocalDate fechaActual = LocalDate.now(); // Obtener la fecha actual como LocalDate
            // Convertir la fecha de inicio de unidad a LocalDate
            Calendar calInicio = Calendar.getInstance();
            calInicio.setTime(unidad.getFechaInicioUnidad());
            LocalDate fechaInicioUnidad = LocalDate.of(calInicio.get(Calendar.YEAR), calInicio.get(Calendar.MONTH) + 1, calInicio.get(Calendar.DAY_OF_MONTH));

            // Convertir la fecha de fin de unidad a LocalDate
            Calendar calFin = Calendar.getInstance();
            calFin.setTime(unidad.getFechaFinUnidad());
            LocalDate fechaFinUnidad = LocalDate.of(calFin.get(Calendar.YEAR), calFin.get(Calendar.MONTH) + 1, calFin.get(Calendar.DAY_OF_MONTH));

            return fechaActual.isEqual(fechaInicioUnidad) || (fechaActual.isAfter(fechaInicioUnidad) && fechaActual.isBefore(fechaFinUnidad));
        }
        return false;
    }

    public double calcularPromedio() {
        double promedio = (notaPractica * 0.3) + (notaProyecto * 0.3) + (notaExamen * 0.4);
        promedio = Math.round(promedio * 10.0) / 10.0; // Redondear el promedio a un decimal
        return promedio;
    }

}
