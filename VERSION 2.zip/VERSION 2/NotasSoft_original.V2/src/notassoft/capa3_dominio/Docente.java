package notassoft.capa3_dominio;

public class Docente extends Persona {

    // Atributos propios de subclase
    private int idDocente;
    private String codDocente;

    // Constructores
    public Docente() {
    }

    public Docente(int idDocente, String codDocente) {
        this.idDocente = idDocente;
        this.codDocente = codDocente;
    }

    // Metodos
    public int getIdDocente() {
        return idDocente;
    }

    public void setIdDocente(int idDocente) {
        this.idDocente = idDocente;
    }

    public String getCodDocente() {
        return codDocente;
    }

    public void setCodDocente(String codDocente) {
        this.codDocente = codDocente;
    }


}
