package notassoft.capa3_dominio;

import java.util.Date;

public class Unidad {

    // Atributos 
    private int codUnidad;
    private String nombreUnidad;
    private Date fechaInicioUnidad;
    private Date fechaFinUnidad;

    // Constructores
    public Unidad() {
    }

    public Unidad(int codUnidad, String nombreUnidad, Date fechaInicioUnidad, Date fechaFinUnidad) {
        this.codUnidad = codUnidad;
        this.nombreUnidad = nombreUnidad;
        this.fechaInicioUnidad = fechaInicioUnidad;
        this.fechaFinUnidad = fechaFinUnidad;
    }

    public Unidad(int codUnidad, String nombreUnidad) {
        this.codUnidad = codUnidad;
        this.nombreUnidad = nombreUnidad;
    }

    // Metodos
    public int getCodUnidad() {
        return codUnidad;
    }

    public void setCodUnidad(int codUnidad) {
        this.codUnidad = codUnidad;
    }

    public String getNombreUnidad() {
        return nombreUnidad;
    }

    public void setNombreUnidad(String nombreUnidad) {
        this.nombreUnidad = nombreUnidad;
    }

    public Date getFechaInicioUnidad() {
        return fechaInicioUnidad;
    }

    public void setFechaInicioUnidad(Date fechaInicioUnidad) {
        this.fechaInicioUnidad = fechaInicioUnidad;
    }

    public Date getFechaFinUnidad() {
        return fechaFinUnidad;
    }

    public void setFechaFinUnidad(Date fechaFinUnidad) {
        this.fechaFinUnidad = fechaFinUnidad;
    }

    public boolean tieneFechaLimiteDelIngresoDeNotasValida() {
        Date fechaActual = new Date();
        return fechaActual.compareTo(fechaInicioUnidad) >= 0 && fechaActual.compareTo(fechaFinUnidad) <= 0;
    }
}
