package notassoft.capa3_dominio;

public class Usuario {

    // Atributos de clase
    private int idUsuario;
    private String username;
    private String contrasena;
    private Docente docente;

    // Constructores
    public Usuario() {
    }

    public Usuario(int idUsuario, String username, String contrasena, Docente docente) {
        this.idUsuario = idUsuario;
        this.username = username;
        this.contrasena = contrasena;
        this.docente = docente;
    }

    // Metodos
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public Docente getDocente() {
        return docente;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }

}
