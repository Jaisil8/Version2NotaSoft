package notassoft.capa3_dominio;

public class Alumno extends Persona {

    // Atributos propios de subclase
    private int idAlumno;
    private String codAlumno;

    // Constructores
    public Alumno() {
    }

    public Alumno(int idAlumno, String codAlumno) {
        this.idAlumno = idAlumno;
        this.codAlumno = codAlumno;
    }

    // Metodos
    public int getIdAlumno() {
        return idAlumno;
    }

    public String getCodAlumno() {
        return codAlumno;
    }

    public void setCodAlumno(String codAlumno) {
        this.codAlumno = codAlumno;
    }

}