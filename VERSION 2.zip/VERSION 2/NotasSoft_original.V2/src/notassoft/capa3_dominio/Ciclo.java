package notassoft.capa3_dominio;

public class Ciclo {

    // Atributos de clase
    private int codCiclo;
    private String nombreCiclo;

    // Contructores
    public Ciclo() {
    }

    public Ciclo(String nombreCiclo) {
        this.nombreCiclo = nombreCiclo;
    }

    public Ciclo(int codCiclo, String nombreCiclo) {
        this.codCiclo = codCiclo;
        this.nombreCiclo = nombreCiclo;
    }

    // Metodos
    public int getCodCiclo() {
        return codCiclo;
    }

    public void setCodCiclo(int codCiclo) {
        this.codCiclo = codCiclo;
    }

    public String getNombreCiclo() {
        return nombreCiclo;
    }

    public void setNombreCiclo(String nombreCiclo) {
        this.nombreCiclo = nombreCiclo;
    }

}
