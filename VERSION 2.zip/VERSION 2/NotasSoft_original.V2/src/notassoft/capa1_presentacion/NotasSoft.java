package notassoft.capa1_presentacion;

public class NotasSoft {

    public static void main(String[] args) {
        new VentanaLogin().setVisible(true);
    }
    
}
