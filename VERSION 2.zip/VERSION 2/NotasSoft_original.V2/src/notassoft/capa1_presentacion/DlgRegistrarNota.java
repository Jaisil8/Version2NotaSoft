package notassoft.capa1_presentacion;

import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import notassoft.capa2_aplicacion.GestionarRegistroNotasServicio;
import notassoft.capa3_dominio.AsignacionCurso;
import notassoft.capa3_dominio.Curso;
import notassoft.capa3_dominio.CustomTableModel;
import notassoft.capa3_dominio.Matricula;
import notassoft.capa3_dominio.Notas;
import notassoft.capa3_dominio.Semestre;
import notassoft.capa3_dominio.Unidad;
import notassoft.capa4_persistencia.AccesoDatos;
import notassoft.capa4_persistencia.AccesoDatosMySQL;
import notassoft.capa4_persistencia.MatriculaMySQL;
import notassoft.capa4_persistencia.ExcepcionPersonalizada;
import notassoft.capa4_persistencia.NotasMySQL;
import notassoft.capa4_persistencia.SemestreMySQL;

public class DlgRegistrarNota extends javax.swing.JDialog {

    transient AccesoDatos accesoDatos = new AccesoDatosMySQL();
    transient NotasMySQL notasDAO = new NotasMySQL(accesoDatos);
    transient MatriculaMySQL matriculaDAO = new MatriculaMySQL(accesoDatos);
    transient GestionarRegistroNotasServicio gestionarRegistroNotasServicio;
    transient Notas notas = new Notas();

    private DefaultTableModel modelo;

    public String idUsuario;
    public String nombdocente;
    private int idcodcurso;
    private int codUnidad;

    public DlgRegistrarNota(String idUsuario, String nombDocente) throws Exception {
        super(VentanaPrincipal.getInstancia(idUsuario, nombDocente), true);
        initComponents();
        this.setTitle("Registrar notas");
        this.idUsuario = idUsuario;
        this.nombdocente = nombDocente;
        gestionarRegistroNotasServicio = new GestionarRegistroNotasServicio();
        lblIdUsuario.setText(idUsuario);
        String contenido = String.valueOf(nombdocente);
        String contenidoEnMayusculas = contenido.toUpperCase();
        nombredocente.setText(contenidoEnMayusculas);
        llenarPeriodo();
        llenarUnidad();
        invisble();
        actualizarnotasdelalumno();
        inicializarTablaAlumnos();

        tblAlumnos.getSelectionModel().addListSelectionListener((ListSelectionEvent event) -> {
            if (!event.getValueIsAdjusting()) {
                try {
                    obtenerIdMatriculaDelAlumno();
                } catch (ExcepcionPersonalizada ex) {
                    Logger.getLogger(DlgRegistrarNota.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

    }

    private void inicializarTablaAlumnos() {
        modelo = new CustomTableModel();
        modelo.addColumn("Código de Alumno");
        modelo.addColumn("Alumno");
        modelo.addColumn("Nota Práctica");
        modelo.addColumn("Nota Proyecto");
        modelo.addColumn("Nota Examen");
        modelo.addColumn("Promedio");

    }

    private void invisble() {
        jLabel9.setVisible(false);
        lbscodsemestre.setVisible(false);
        lblIdUsuario.setVisible(false);
        jLabel10.setVisible(false);
        jLabel6.setVisible(false);
        lbscodAsignacion.setVisible(false);
        lbscodMatricula.setVisible(false);
        lbsidcurso.setVisible(false);
        lbsidunidad.setVisible(false);
        lbsnombreCiclo.setText("");
        lbsnumeroAula.setText("");
        lbsnombreTurno.setText("");
        lbsHorario.setText("");
        lbscodMatricula.setText("");

    }

    private void llenarPeriodo() throws Exception {
        String codsemestre = lbscodsemestre.getText(); // Obtén el valor de lbscodsemestre
        try {
            SemestreMySQL semestreDAO = new SemestreMySQL(accesoDatos);
            List<Semestre> semestres = semestreDAO.obtenerSemestres();

            DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<>();
            for (Semestre semestre : semestres) {
                comboBoxModel.addElement(semestre.getPeriodo());
                codsemestre = (semestre.getCodSemestre() + "");
                lbscodsemestre.setText(String.valueOf(codsemestre)); // Actualiza el valor de lbscodsemestre con el código del semestre
            }
            cbxperiodo.setModel(comboBoxModel);
            llenarCurso();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error al obtener los semestres: " + e.getMessage());
        }
    }

    public void llenarCurso() throws Exception {
        String codigoSemestre = lbscodsemestre.getText(); // Obtén el valor de lbscodsemestre

        try {
            List<Curso> cursos = (List<Curso>) gestionarRegistroNotasServicio.obtenerCursos(idUsuario, Integer.parseInt(codigoSemestre));

            // Actualiza tu componente de la interfaz gráfica con los cursos obtenidos
            // Por ejemplo, si tienes un JComboBox llamado cbxCursosDisponibles:
            DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<>();
            //comboBoxModel.addElement("-Seleccionar-"); // Agrega el primer elemento
            for (Curso curso : cursos) {
                comboBoxModel.addElement(curso.getNombreCurso());
            }
            cbxCurso.setModel(comboBoxModel);

            // Agrega un ActionListener al cbxCurso para capturar los eventos de selección
            cbxCurso.addActionListener((ActionEvent e) -> {
                int selectedIndex = cbxCurso.getSelectedIndex();
                if (selectedIndex >= 0) {
                    Curso selectedCurso = cursos.get(selectedIndex);
                    idcodcurso = (selectedCurso.getCodCurso());
                    lbsidcurso.setText(String.valueOf(idcodcurso)); // Actualiza el valor de lbsidcurso con el código del curso seleccionado
                    llenarAsignacionCurso(lbscodAsignacion);
                    llenarobtenerAsignacion(lbsnombreCiclo, lbsnumeroAula, lbsnombreTurno, lbsHorario);
                }
            });

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error al obtener los cursos: " + e.getMessage());
        }
    }

    private void llenarUnidad() throws Exception {
        String codigoSemestre = lbscodsemestre.getText(); // Obtén el valor de lbscodsemestre

        try {
            List<Unidad> unidades = (List<Unidad>) gestionarRegistroNotasServicio.obtenerUnidadesPorSemestre(Integer.parseInt(codigoSemestre));

            // Actualiza tu componente de la interfaz gráfica con los cursos obtenidos
            // Por ejemplo, si tienes un JComboBox llamado cbxCursosDisponibles:
            DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<>();
            // comboBoxModel.addElement("-Seleccionar-"); // Agrega el primer elemento
            for (Unidad unidad : unidades) {
                comboBoxModel.addElement(unidad.getNombreUnidad());
            }
            cboUnidad.setModel(comboBoxModel);
            // Agrega un Action al cbxCurso para capturar los eventos de selección
            cboUnidad.addActionListener((ActionEvent e) -> {
                int selectedIndex = cboUnidad.getSelectedIndex();
                if (selectedIndex >= 0) {
                    Unidad selectedUnidad = unidades.get(selectedIndex);
                    codUnidad = (selectedUnidad.getCodUnidad());
                    lbsidunidad.setText(String.valueOf(codUnidad)); // Actualiza el valor de lbsidcurso con el código del curso seleccionado
                }
            });
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error al obtener las unidades: " + e.getMessage());
        }
    }

    public void llenarAsignacionCurso(JLabel lbscodAsignacion) {

        try {
            int codigoCurso = Integer.parseInt(lbsidcurso.getText());
            int codigoSemestre = Integer.parseInt(lbscodsemestre.getText());

            AsignacionCurso asignacionCurso = gestionarRegistroNotasServicio.obtenerAsignacionesPorCursoYSemestre(codigoSemestre, codigoCurso);
            if (asignacionCurso != null) {
                lbscodAsignacion.setText(String.valueOf(asignacionCurso.getCodAsignacion()));
            } else {
                // Manejo de caso donde no se encontró una asignación de curso para los criterios de búsqueda
                JOptionPane.showMessageDialog(null, "No se encontró asignación del curso");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al obtener la asignación de curso: " + e.getMessage(), ExcepcionPersonalizada.MENSAJE_ERROR, JOptionPane.ERROR_MESSAGE);
        }
    }

    public void llenarobtenerAsignacion(JLabel lbsnombreCiclo, JLabel lbsnumeroAula, JLabel lbsnombreTurno, JLabel lbsHorario) {

        try {
            int codigoAsignacion = Integer.parseInt(lbsidcurso.getText());

            AsignacionCurso asignacionCurso = gestionarRegistroNotasServicio.obtenerAsignacion(codigoAsignacion);
            lbsnombreCiclo.setText(asignacionCurso.getCurso().getCiclo().getNombreCiclo());
            lbsnumeroAula.setText(String.valueOf(asignacionCurso.getAula().getNumeroAula()));
            lbsnombreTurno.setText(asignacionCurso.getTurno().getNombreTurno());
            lbsHorario.setText(asignacionCurso.getTurno().getHorario());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al obtener el detalle del curso: " + e.getMessage(), ExcepcionPersonalizada.MENSAJE_ERROR, JOptionPane.ERROR_MESSAGE);
        }
    }

    public void obtenerIdMatriculaDelAlumno() throws ExcepcionPersonalizada {
        int filaSeleccionada = tblAlumnos.getSelectedRow();
        if (filaSeleccionada != -1) {
            String codAlumnoStr = modelo.getValueAt(filaSeleccionada, 0).toString(); // Obtener el código del alumno como cadena
            long codAlumno = Long.parseLong(codAlumnoStr); // Convertir la cadena a entero
            try {
                Matricula matricula = matriculaDAO.buscarMatricula(codAlumno);
                int idMatricula = matricula.getIdMatricula();
                lbscodMatricula.setText(Integer.toString(idMatricula));
            } catch (SQLException e) {
                // Manejar otras excepciones
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        roundedPanel1 = new gamm_Panel.RoundedPanel();
        cbxCurso = new gamm_ComboBox.Combobox();
        lbsidcurso = new javax.swing.JLabel();
        cboUnidad = new gamm_ComboBox.Combobox();
        lbsidunidad = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lbsnombreCiclo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lbsnumeroAula = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lbsnombreTurno = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lbsHorario = new javax.swing.JLabel();
        lbscodMatricula = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        roundedPanel2 = new gamm_Panel.RoundedPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblAlumnos = new javax.swing.JTable();
        roundedPanel3 = new gamm_Panel.RoundedPanel();
        cbxperiodo = new gamm_ComboBox.Combobox();
        lbscodsemestre = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        nombredocente = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lblIdUsuario = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lbscodAsignacion = new javax.swing.JLabel();
        btnListarAlumnos = new gamm_Button.Button();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        roundedPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true), "Curso asignado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto", 0, 14))); // NOI18N

        cbxCurso.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)), "CURSO", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto", 1, 14))); // NOI18N
        cbxCurso.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        cbxCurso.setLabeText("");

        lbsidcurso.setText("codCurso");

        cboUnidad.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)), "UNIDAD", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14))); // NOI18N
        cboUnidad.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        cboUnidad.setLabeText("");

        lbsidunidad.setText("codUnidad");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("CICLO:");

        lbsnombreCiclo.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        lbsnombreCiclo.setText("nombreCiclo");

        jLabel3.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("AULA:");

        lbsnumeroAula.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        lbsnumeroAula.setText("numAula");

        jLabel5.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("TURNO:");

        lbsnombreTurno.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        lbsnombreTurno.setText("nombreTurno");

        jLabel4.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("HORARIO:");

        lbsHorario.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        lbsHorario.setText("horario");

        lbscodMatricula.setText("idMatricula");

        jLabel6.setText("IDMatricula:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbsnombreCiclo, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbsnumeroAula, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel6)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(lbscodMatricula)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(lbsHorario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbsnombreTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lbsnombreCiclo))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(lbsnumeroAula))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbsnombreTurno)
                    .addComponent(jLabel5))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lbsHorario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbscodMatricula)
                    .addComponent(jLabel6))
                .addContainerGap())
        );

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(lbsidcurso, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(cbxCurso, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(43, 43, 43)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboUnidad, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(lbsidunidad, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel1Layout.createSequentialGroup()
                                .addComponent(cboUnidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lbsidunidad)
                                .addGap(3, 3, 3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel1Layout.createSequentialGroup()
                                .addComponent(cbxCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)))
                        .addComponent(lbsidcurso)))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        roundedPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Lista de alumnos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto", 0, 14))); // NOI18N

        tblAlumnos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblAlumnos.setRowHeight(25);
        jScrollPane1.setViewportView(tblAlumnos);

        javax.swing.GroupLayout roundedPanel2Layout = new javax.swing.GroupLayout(roundedPanel2);
        roundedPanel2.setLayout(roundedPanel2Layout);
        roundedPanel2Layout.setHorizontalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 913, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        roundedPanel2Layout.setVerticalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        cbxperiodo.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)), "PERIODO", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14))); // NOI18N
        cbxperiodo.setEnabled(false);
        cbxperiodo.setLabeText("");

        lbscodsemestre.setText("idperiodo");

        javax.swing.GroupLayout roundedPanel3Layout = new javax.swing.GroupLayout(roundedPanel3);
        roundedPanel3.setLayout(roundedPanel3Layout);
        roundedPanel3Layout.setHorizontalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbxperiodo, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbscodsemestre)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel3Layout.setVerticalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lbscodsemestre)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cbxperiodo, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(223, 223, 223))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("DOCENTE: ");

        nombredocente.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nombredocente.setText("NOMBRE DEL DOCENTE");

        jLabel9.setText("IDUSUARIO");
        jLabel9.setFocusCycleRoot(true);
        jLabel9.setFocusable(false);

        lblIdUsuario.setText("null");
        lblIdUsuario.setOpaque(true);

        jLabel10.setText("CODASIGNACION");

        lbscodAsignacion.setText("null");

        btnListarAlumnos.setBackground(new java.awt.Color(0, 102, 153));
        btnListarAlumnos.setForeground(new java.awt.Color(255, 255, 255));
        btnListarAlumnos.setText("Listar Alumnos");
        btnListarAlumnos.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        btnListarAlumnos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarAlumnosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblIdUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbscodAsignacion, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nombredocente, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnListarAlumnos, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(128, 128, 128))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(lblIdUsuario)
                            .addComponent(jLabel10)
                            .addComponent(lbscodAsignacion))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nombredocente, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(btnListarAlumnos, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(131, 131, 131))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnListarAlumnosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarAlumnosActionPerformed

        try {
            int codigoAsignacion = Integer.parseInt(lbscodAsignacion.getText());
            lbsidunidad.setText(String.valueOf(codUnidad));

            ResultSet resultado = notasDAO.obtenerNotas(codigoAsignacion, codUnidad);

            // Almacenar los datos en una lista
            List<Object[]> datos = new ArrayList<>();
            while (resultado.next()) {

                String codAlumno = resultado.getString("codAlumno");
                String alumno = resultado.getString("Alumno");
                double notaPractica = resultado.getDouble("nota_Practica");
                double notaProyecto = resultado.getDouble("nota_Proyecto");
                double notaExamen = resultado.getDouble("nota_Examen");

                Notas nota = new Notas(notaPractica, notaProyecto, notaExamen);
                double promedio = nota.calcularPromedio();

                datos.add(new Object[]{codAlumno, alumno, notaPractica, notaProyecto, notaExamen, promedio});
            }
            modelo.setRowCount(0);
            // Agregar los datos al modelo de tabla
            for (Object[] fila : datos) {
                modelo.addRow(fila);
            }

            tblAlumnos.setModel(modelo);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener el detalle del curso: " + e.getMessage(), ExcepcionPersonalizada.MENSAJE_ERROR, JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnListarAlumnosActionPerformed

    private void actualizarnotasdelalumno() {
        tblAlumnos.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    int filaSeleccionada = tblAlumnos.getSelectedRow();
                    int columnaSeleccionada = tblAlumnos.getSelectedColumn();
                    if (esColumnaValida(columnaSeleccionada)) {
                        String notaPracticaStr = obtenerValorTabla(filaSeleccionada, 2);
                        String notaProyectoStr = obtenerValorTabla(filaSeleccionada, 3);
                        String notaExamenStr = obtenerValorTabla(filaSeleccionada, 4);
                        if (esValorNumerico(notaPracticaStr) && esValorNumerico(notaProyectoStr) && esValorNumerico(notaExamenStr)) {
                            double notaPractica = Double.parseDouble(notaPracticaStr);
                            double notaProyecto = Double.parseDouble(notaProyectoStr);
                            double notaExamen = Double.parseDouble(notaExamenStr);
                            validarNotas(notaPractica, notaProyecto, notaExamen);
                          
                        }
                    }
                }
            }
        });
    }

    private boolean esColumnaValida(int columnaSeleccionada) {
        return columnaSeleccionada == 2 || columnaSeleccionada == 3 || columnaSeleccionada == 4;
    }

    private String obtenerValorTabla(int fila, int columna) {
        return tblAlumnos.getValueAt(fila, columna).toString();
    }

    private boolean esValorNumerico(String valor) {
        return notas.validarNumeros(valor);
    }

    private void validarNotas(double notaPractica, double notaProyecto, double notaExamen) {
        notas.setNotaPractica(notaPractica);
        notas.setNotaProyecto(notaProyecto);
        notas.setNotaExamen(notaExamen);

        if (notas.validarNotasEnRango()) {
            int asignacionCodigo = Integer.parseInt(lbscodAsignacion.getText());
            int idMatricula = Integer.parseInt(lbscodMatricula.getText());
            int codigoUnidad = Integer.parseInt(lbsidunidad.getText());

            try {
                gestionarRegistroNotasServicio.actualizarNotas(notaPractica, notaProyecto, notaExamen, asignacionCodigo, idMatricula, codigoUnidad);

                double promedio = notas.calcularPromedio();
                if (promedio >= 0 && promedio <= 20) {
                    // El promedio es válido, actualiza el valor en la tabla
                    int filaSeleccionada = tblAlumnos.getSelectedRow();
                    modelo.setValueAt(promedio, filaSeleccionada, 5); // Reemplaza 5 con el índice correcto de la columna "Promedio"
                } else {
                    // El promedio no es válido, muestra un mensaje de error
                    JOptionPane.showMessageDialog(null, "El promedio calculado no está en el rango de 0 a 20.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error al actualizar las notas: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Las notas deben estar en el rango de 0 a 20.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DlgRegistrarNota.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DlgRegistrarNota.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DlgRegistrarNota.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DlgRegistrarNota.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                String iDUsuario = null; // Reemplaza con el valor correcto del ID de usuario
                String nombDocente = null; // R
                DlgRegistrarNota dialog = new DlgRegistrarNota(iDUsuario, nombDocente);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            } catch (Exception ex) {
                Logger.getLogger(DlgRegistrarNota.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private gamm_Button.Button btnListarAlumnos;
    private gamm_ComboBox.Combobox cboUnidad;
    public gamm_ComboBox.Combobox cbxCurso;
    private gamm_ComboBox.Combobox cbxperiodo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    public javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblIdUsuario;
    private javax.swing.JLabel lbsHorario;
    private javax.swing.JLabel lbscodAsignacion;
    private javax.swing.JLabel lbscodMatricula;
    private javax.swing.JLabel lbscodsemestre;
    private javax.swing.JLabel lbsidcurso;
    private javax.swing.JLabel lbsidunidad;
    private javax.swing.JLabel lbsnombreCiclo;
    private javax.swing.JLabel lbsnombreTurno;
    private javax.swing.JLabel lbsnumeroAula;
    private javax.swing.JLabel nombredocente;
    private gamm_Panel.RoundedPanel roundedPanel1;
    private gamm_Panel.RoundedPanel roundedPanel2;
    private gamm_Panel.RoundedPanel roundedPanel3;
    private javax.swing.JTable tblAlumnos;
    // End of variables declaration//GEN-END:variables
}
