package notassoft.capa1_presentacion;

import java.awt.Image;
import java.awt.Toolkit;

public class VentanaPrincipal extends javax.swing.JFrame {

    private static VentanaPrincipal instancia;

    public static VentanaPrincipal getInstancia(String idUsuario, String nombDocente) {
        if (instancia == null) {
            instancia = new VentanaPrincipal(idUsuario, nombDocente);
        }
        return instancia;
    }

    public VentanaPrincipal(String idUsuario, String nombDocente) {
        initComponents();
        this.setTitle("Menu principal");
        this.setResizable(false);
        this.setIconImage(getIconImage()); //Establecer icono para la aplicacion  
        lblIdUsuario.setText(idUsuario);
        lblNomDocente.setText(nombDocente);

    }

    @Override
    public Image getIconImage() { //Establecer icono de programa
        Image icono;
        icono = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("imagenes/icon.png"));  //obtener el objeto de imagen 
        return icono;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lblIdUsuario = new javax.swing.JLabel();
        lblNomDocente = new javax.swing.JLabel();
        btnCerrarSesion = new gamm_Button.Button();
        roundedPanel1 = new gamm_Panel.RoundedPanel();
        btnregistrarnotas = new gamm_Button.Button();
        btnReporteNotas = new gamm_Button.Button();
        btnCursosAsignados = new gamm_Button.Button();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        bgPrincipal = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 0, 180));

        jLabel2.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("DOCENTE");

        lblIdUsuario.setForeground(new java.awt.Color(0, 0, 0,180));
        lblIdUsuario.setText("idUsuario");

        lblNomDocente.setFont(new java.awt.Font("Roboto", 0, 20)); // NOI18N
        lblNomDocente.setForeground(new java.awt.Color(255, 255, 255));
        lblNomDocente.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNomDocente.setText("nombre docente");

        btnCerrarSesion.setBackground(new java.awt.Color(102, 102, 102));
        btnCerrarSesion.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrarSesion.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        btnCerrarSesion.setLabel("Cerrar Sesión");
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(lblNomDocente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblIdUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(163, 163, 163))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(134, Short.MAX_VALUE)
                .addComponent(btnCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(128, 128, 128))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(lblNomDocente)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblIdUsuario)
                .addGap(18, 18, 18)
                .addComponent(btnCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 540, 400, 190));

        btnregistrarnotas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/nota.png"))); // NOI18N
        btnregistrarnotas.setBorderPainted(false);
        btnregistrarnotas.setFocusable(false);
        btnregistrarnotas.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        btnregistrarnotas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnregistrarnotas.setRequestFocusEnabled(false);
        btnregistrarnotas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnregistrarnotas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnregistrarnotasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnregistrarnotasMouseExited(evt);
            }
        });
        btnregistrarnotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnregistrarnotasActionPerformed(evt);
            }
        });

        btnReporteNotas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/reporte.png"))); // NOI18N
        btnReporteNotas.setBorderPainted(false);
        btnReporteNotas.setFocusable(false);
        btnReporteNotas.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        btnReporteNotas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnReporteNotas.setRequestFocusEnabled(false);
        btnReporteNotas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnReporteNotas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnReporteNotasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnReporteNotasMouseExited(evt);
            }
        });

        btnCursosAsignados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/libros.png"))); // NOI18N
        btnCursosAsignados.setBorderPainted(false);
        btnCursosAsignados.setFocusable(false);
        btnCursosAsignados.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        btnCursosAsignados.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCursosAsignados.setRequestFocusEnabled(false);
        btnCursosAsignados.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCursosAsignados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCursosAsignadosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCursosAsignadosMouseExited(evt);
            }
        });

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(btnregistrarnotas, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btnCursosAsignados, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                .addGap(30, 30, 30)
                .addComponent(btnReporteNotas, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCursosAsignados, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReporteNotas, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnregistrarnotas, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
        );

        jPanel1.add(roundedPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 170, 720, 160));

        jPanel3.setBackground(new java.awt.Color(250, 250, 250,150));

        jLabel6.setFont(new java.awt.Font("Roboto", 1, 48)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("MENU");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel6)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 30, 720, -1));

        bgPrincipal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/bgPrincipal.jpg"))); // NOI18N
        jPanel1.add(bgPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnregistrarnotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregistrarnotasActionPerformed
       String idu = lblIdUsuario.getText();
       String ndoc=lblNomDocente.getText();
        try {
            DlgRegistrarNota dlgRegistrarNota = new DlgRegistrarNota(idu, ndoc);
            dlgRegistrarNota.setVisible(true);
            
        } catch (Exception e) {
           // Manejo de la excepción

        }

    }//GEN-LAST:event_btnregistrarnotasActionPerformed

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        new VentanaLogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    private void btnregistrarnotasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnregistrarnotasMouseEntered
        btnregistrarnotas.setText("REGISTRAR NOTAS");
    }//GEN-LAST:event_btnregistrarnotasMouseEntered

    private void btnregistrarnotasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnregistrarnotasMouseExited
        btnregistrarnotas.setText("");
    }//GEN-LAST:event_btnregistrarnotasMouseExited

    private void btnReporteNotasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReporteNotasMouseEntered
        btnReporteNotas.setText("REPORTE");
    }//GEN-LAST:event_btnReporteNotasMouseEntered

    private void btnReporteNotasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReporteNotasMouseExited
        btnReporteNotas.setText("");
    }//GEN-LAST:event_btnReporteNotasMouseExited

    private void btnCursosAsignadosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCursosAsignadosMouseEntered
        btnCursosAsignados.setText("CURSOS ASIGNADOS");
    }//GEN-LAST:event_btnCursosAsignadosMouseEntered

    private void btnCursosAsignadosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCursosAsignadosMouseExited
        btnCursosAsignados.setText("");
    }//GEN-LAST:event_btnCursosAsignadosMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            String Usuario = null; // Reemplaza con el valor correcto del ID de usuario
            String nombdocente = null;
            VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(Usuario, nombdocente);
            ventanaPrincipal.setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bgPrincipal;
    private gamm_Button.Button btnCerrarSesion;
    private gamm_Button.Button btnCursosAsignados;
    private gamm_Button.Button btnReporteNotas;
    private gamm_Button.Button btnregistrarnotas;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblIdUsuario;
    private javax.swing.JLabel lblNomDocente;
    private gamm_Panel.RoundedPanel roundedPanel1;
    // End of variables declaration//GEN-END:variables
}
