package notassoft.capa4_persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioMySQL {

    private final AccesoDatos accesoDatos;

    public UsuarioMySQL(AccesoDatos accesoDatos) {
        this.accesoDatos = accesoDatos;
    }

    public boolean verificarUsuario(String username, String contrasena) throws SQLException, ExcepcionPersonalizada {
        boolean usuarioValido = false;

        try {
            accesoDatos.abrirConexion();

            String sql = "SELECT * FROM usuario WHERE username=? AND contraseña = ?";
            PreparedStatement sentencia = accesoDatos.prepararSentencia(sql);
            sentencia.setString(1, username);
            sentencia.setString(2, contrasena);

            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                usuarioValido = true;
            }
        } catch (SQLException | ExcepcionPersonalizada e) {
            throw new SQLException("Ocurrió un problema al verificar el usuario", e);
        } finally {
            accesoDatos.cerrarConexion();
        }

        return usuarioValido;
    }

    public String obtenerIdUsuario(String username) throws SQLException, ExcepcionPersonalizada {
        String idUsuario = null;

        try {
            accesoDatos.abrirConexion();

            String sql = "SELECT idUsuario FROM usuario WHERE username = ?";
            PreparedStatement sentencia = accesoDatos.prepararSentencia(sql);
            sentencia.setString(1, username);

            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                idUsuario = resultado.getString("idUsuario");
            }
        } catch (SQLException | ExcepcionPersonalizada e) {
            throw new SQLException("Ocurrió un problema al obtener el idUsuario", e);
        } finally {
            accesoDatos.cerrarConexion();
        }

        return idUsuario;
    }

    public String obtenerNomDocente(String username) throws SQLException, ExcepcionPersonalizada {
        String nomDocente = null;

        try {
            accesoDatos.abrirConexion();

            String sql = "SELECT CONCAT(apellidoPaterno, ' ', apellidoMaterno, ' ', nombres) AS nombdocente "
                    + "FROM usuario u "
                    + "INNER JOIN docente d ON d.idDocente = u.idDocente "
                    + "INNER JOIN persona p ON p.idPersona = d.idPersona "
                    + "WHERE username = ?";
            PreparedStatement sentencia = accesoDatos.prepararSentencia(sql);
            sentencia.setString(1, username);

            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                nomDocente = resultado.getString("nombdocente");
            }
        } catch (SQLException | ExcepcionPersonalizada e) {
            throw new SQLException("Ocurrió un problema al obtener el nomdocente", e);
        } finally {
            accesoDatos.cerrarConexion();
        }

        return nomDocente;
    }

}
