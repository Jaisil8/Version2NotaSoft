package notassoft.capa4_persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import notassoft.capa3_dominio.AsignacionCurso;
import notassoft.capa3_dominio.Aula;
import notassoft.capa3_dominio.Ciclo;
import notassoft.capa3_dominio.Curso;
import notassoft.capa3_dominio.Turno;

public class AsignacionCursoMySQL {

    private AccesoDatos accesoDatos;

    public AsignacionCursoMySQL(AccesoDatos accesoDatos) {
        this.accesoDatos = accesoDatos;
    }

    public AsignacionCurso obtenerAsignacionesPorCursoYSemestre(int codCurso, int codSemestre) throws SQLException, ExcepcionPersonalizada {
        String sql = "SELECT a.codAsignacion "
                + "FROM curso c "
                + "INNER JOIN ciclo ci ON ci.codCiclo = c.codCiclo "
                + "INNER JOIN asignacionCurso a ON a.codCurso = c.codCurso "
                + "INNER JOIN aula au ON au.codAula = a.codAula "
                + "INNER JOIN turno t ON t.codTurno = a.codTurno "
                + "INNER JOIN docente d ON d.idDocente = a.idDocente "
                + "INNER JOIN usuario u ON u.idDocente = d.idDocente "
                + "INNER JOIN semestre s ON s.codSemestre = a.codSemestre "
                + "WHERE c.codCurso = ? AND s.codSemestre = ?";
        PreparedStatement sentencia;

        try {
            sentencia = accesoDatos.prepararSentencia(sql);
            sentencia.setInt(1, codCurso);
            sentencia.setInt(2, codSemestre);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                AsignacionCurso asignacion = new AsignacionCurso();
                asignacion.setCodAsignacion(resultado.getInt("codAsignacion"));
                return asignacion;
            }
        } catch (SQLException ex) {
            // handle the exception
        }
        return null;
    }

    public AsignacionCurso obtenerAsignacion(int codAsignacion) throws SQLException, ExcepcionPersonalizada {
        String sql = "select nombreCiclo, numeroAula, nombreTurno, horario "
                + "from asignacionCurso ac "
                + "inner join curso c on c.codCurso = ac.codCurso "
                + "inner join ciclo ci on ci.codCiclo =  c.codCiclo "
                + "inner join aula a on a.codAula = ac.codAula "
                + "inner join turno t on t.codTurno = ac.codTurno "
                + "where codAsignacion= ?;";
        PreparedStatement sentencia;

        try {
            sentencia = accesoDatos.prepararSentencia(sql);
            sentencia.setInt(1, codAsignacion);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                AsignacionCurso asignacion = new AsignacionCurso();

                Curso curso = new Curso();
                Ciclo ciclo = new Ciclo(); // Crea un objeto Ciclo
                ciclo.setNombreCiclo(resultado.getString("nombreCiclo"));
                curso.setCiclo(ciclo);
                asignacion.setCurso(curso);

                Aula aula = new Aula();
                aula.setNumeroAula(resultado.getString("numeroAula"));
                asignacion.setAula(aula);

                Turno turno = new Turno();
                turno.setNombreTurno(resultado.getString("nombreTurno"));
                turno.setHorario(resultado.getString("horario"));
                asignacion.setTurno(turno);

                return asignacion;
            }
        } catch (SQLException ex) {
            // handle the exception
        }
        return null;
    }

}
