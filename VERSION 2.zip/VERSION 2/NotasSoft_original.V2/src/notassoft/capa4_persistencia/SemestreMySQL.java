package notassoft.capa4_persistencia;

/**
 *
 * @author jaisil
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import notassoft.capa3_dominio.Semestre;

public class SemestreMySQL {

    private final AccesoDatos accesoDatos;

    public SemestreMySQL(AccesoDatos accesoDatos) {
        this.accesoDatos = accesoDatos;
    }

    public List<Semestre> obtenerSemestres() throws SQLException, ExcepcionPersonalizada {
        List<Semestre> semestres = new ArrayList<>();

        try {
            accesoDatos.abrirConexion();

            String sql = "SELECT codSemestre, periodo FROM semestre "
                    + "WHERE CURDATE() BETWEEN fechaInicio_Semestre AND fechaFin_Semestre";
            PreparedStatement sentencia = accesoDatos.prepararSentencia(sql);

            ResultSet resultado = sentencia.executeQuery();
            while (resultado.next()) {
                int codSemestre = resultado.getInt("codSemestre");
                String periodo = resultado.getString("periodo");

                Semestre semestre = new Semestre(codSemestre, periodo);
                semestres.add(semestre);
            }
        } catch (SQLException | ExcepcionPersonalizada e) {
            throw new SQLException("Ocurrió un problema al obtener los semestres", e);
        } finally {
            accesoDatos.cerrarConexion();
        }

        return semestres;
    }
}