package notassoft.capa4_persistencia;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import notassoft.capa3_dominio.Notas;

public class NotasMySQL  implements Serializable{

    private final AccesoDatos accesoDatos;

    public NotasMySQL(AccesoDatos accesoDatos) {
        this.accesoDatos = accesoDatos;
    }

    public ResultSet obtenerNotas(int codAsignacion, int codUnidad) throws SQLException {
        try {
            accesoDatos.abrirConexion();
            PreparedStatement sentencia = accesoDatos.prepararSentencia(
                    "SELECT codAlumno, CONCAT(nombres, ' ', apellidoPaterno, ' ', apellidoMaterno) AS Alumno, "
                    + "nota_Practica, nota_Proyecto, nota_Examen "
                    + "FROM notas n "
                    + "INNER JOIN matricula m ON m.idMatricula = n.idMatricula "
                    + "INNER JOIN alumno a ON a.idAlumno = m.idAlumno "
                    + "INNER JOIN persona p ON p.idPersona = a.idPersona "
                    + "WHERE codAsignacion = ? AND codUnidad = ?"
            );
            sentencia.setInt(1, codAsignacion);
            sentencia.setInt(2, codUnidad);
            ResultSet resultado = sentencia.executeQuery();
            return resultado;
        } catch (SQLException | ExcepcionPersonalizada e) {
            throw new SQLException("Ocurrió un problema en la conexion al obtener las notas", e);
        }
    }

    public Notas actualizarNotas(double notaPractica, double notaProyecto, double notaExamen, int codAsignacion, int idMatricula, int codUnidad) throws SQLException, ExcepcionPersonalizada {
        String updateSQL = "UPDATE notas SET nota_Practica = ?, nota_Proyecto = ?, nota_Examen = ? WHERE codAsignacion = ? and idMatricula = ? and codUnidad = ?;";
        try (PreparedStatement sentencia = accesoDatos.prepararSentencia(updateSQL)) {
            sentencia.setDouble(1, notaPractica);
            sentencia.setDouble(2, notaProyecto);
            sentencia.setDouble(3, notaExamen);
            sentencia.setInt(4, codAsignacion);
            sentencia.setInt(5, idMatricula);
            sentencia.setInt(6, codUnidad);

            sentencia.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Ocurrió un problema en la conexión al guardar las notas", e);
        }
        return null;

    }
    
}
