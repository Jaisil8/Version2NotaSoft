package notassoft.capa4_persistencia;

import java.io.Serializable;
import java.sql.*;

public abstract class AccesoDatos implements Serializable{
    protected Connection conexion;

    public abstract void abrirConexion() throws ExcepcionPersonalizada;

    public void cerrarConexion() throws ExcepcionPersonalizada {
        try {
            conexion.close();
        } catch (SQLException e) {
            throw new ExcepcionPersonalizada(ExcepcionPersonalizada.MENSAJE_CONEXION + "al cerrar", e);
        }
    }

    public void iniciarTransaccion() throws ExcepcionPersonalizada {
        try {
            conexion.setAutoCommit(false);
        } catch (SQLException e) {
            throw new ExcepcionPersonalizada(ExcepcionPersonalizada.MENSAJE_CONEXION+"al iniciar la transacción", e);
        }
    }

    public void terminarTransaccion() throws ExcepcionPersonalizada {
        try {
            conexion.commit();
            conexion.setAutoCommit(true);
            conexion.close();
        } catch (SQLException e) {
            throw new ExcepcionPersonalizada(ExcepcionPersonalizada.MENSAJE_CONEXION+"al terminar transacción", e);
        }
    }

    public void cancelarTransaccion() throws ExcepcionPersonalizada {
        try {
            conexion.rollback();
            conexion.setAutoCommit(true);
            conexion.close();
        } catch (SQLException e) {
            throw new ExcepcionPersonalizada(ExcepcionPersonalizada.MENSAJE_CONEXION+"al cancelar la transacción", e);
        }
    }

    public PreparedStatement prepararSentencia(String sql) throws ExcepcionPersonalizada {
        try {
            return conexion.prepareStatement(sql);
        } catch (SQLException e) {
            throw new ExcepcionPersonalizada(ExcepcionPersonalizada.MENSAJE_CONEXION+"al preparar la sentencia", e);
        }
    }

    public ResultSet ejecutarConsulta(String sql) throws ExcepcionPersonalizada {
        try (Statement sentencia = conexion.createStatement()) {
            ResultSet resultado = sentencia.executeQuery(sql);
            return resultado;
        } catch (Exception e) {
            throw new ExcepcionPersonalizada(ExcepcionPersonalizada.MENSAJE_CONEXION+"al ejecutar la consulta", e);
        }
    }
}

