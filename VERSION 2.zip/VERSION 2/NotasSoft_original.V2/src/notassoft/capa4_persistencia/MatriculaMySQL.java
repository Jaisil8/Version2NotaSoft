package notassoft.capa4_persistencia;

import java.io.Serializable;
import notassoft.capa3_dominio.Matricula;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author jaisil
 */
public class MatriculaMySQL implements Serializable {

    private final AccesoDatos accesoDatos;

    public MatriculaMySQL(AccesoDatos accesoDatos) {
        this.accesoDatos = accesoDatos;
    }

    public Matricula buscarMatricula(long codAlumno) throws SQLException, ExcepcionPersonalizada {
        String consultaSQL = "SELECT idMatricula FROM matricula m INNER JOIN alumno a ON a.idAlumno = m.idAlumno WHERE codAlumno = ?";
        PreparedStatement setencia;

        try {
            setencia = accesoDatos.prepararSentencia(consultaSQL);
            setencia.setLong(1, codAlumno);
            ResultSet resultado = setencia.executeQuery();

            if (resultado.next()) {
                Matricula matricula = new Matricula();
                matricula.setIdMatricula(resultado.getInt("idMatricula"));
                return matricula;
            } else {
                throw new ExcepcionPersonalizada("NO EXISTE EL ESTUDIANTE.", null);
            }
        } catch (SQLException e) {
            throw new SQLException("ERROR DE CONEXIÓN AL ENCONTRAR EL CÓDIGO DEL ALUMNO", e);
        }
    }
}

