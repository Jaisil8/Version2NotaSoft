package notassoft.capa4_persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import notassoft.capa3_dominio.Curso;

public class CursoMySQL {

    private AccesoDatos accesoDatos;

    public CursoMySQL(AccesoDatos accesoDatos) {
        this.accesoDatos = accesoDatos;
    }

    public List<Curso> obtenerCursos(String idUsuario, int codSemestre) throws SQLException, ExcepcionPersonalizada {
        List<Curso> cursos = new ArrayList<>();

        try {
            accesoDatos.abrirConexion();

            String sql = "SELECT c.codCurso, c.nombreCurso FROM curso c "
                    + "INNER JOIN asignacionCurso a ON a.codCurso = c.codCurso "
                    + "INNER JOIN docente d ON d.idDocente = a.idDocente "
                    + "INNER JOIN usuario u ON u.idDocente = d.idDocente "
                    + "INNER JOIN semestre s ON s.codSemestre = a.codSemestre "
                    + "WHERE idUsuario = ? AND s.codSemestre = ?";
            PreparedStatement sentencia = accesoDatos.prepararSentencia(sql);
            sentencia.setString(1, idUsuario);
            sentencia.setInt(2, codSemestre);

            ResultSet resultado = sentencia.executeQuery();
            while (resultado.next()) {
                int codCurso = resultado.getInt("codCurso");
                String nombreCurso = resultado.getString("nombreCurso");

                Curso curso = new Curso(codCurso, nombreCurso);
                cursos.add(curso);
            }
        } catch (SQLException | ExcepcionPersonalizada e) {
            throw new SQLException("Ocurrió un problema al obtener los cursos", e);
        } finally {
            accesoDatos.cerrarConexion();
        }

        return cursos;
    }
}
