package notassoft.capa4_persistencia;

/**
 * Excepción personalizada para manejar errores específicos en la capa de
 * persistencia.
 */
public class ExcepcionPersonalizada extends Exception {

    public static final String MENSAJE_CONEXION = "Ocurrió un problema con la conexión";

    public ExcepcionPersonalizada(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }

    public static void EstudianteNoExisteException(String mensaje) throws ExcepcionPersonalizada {
        throw new ExcepcionPersonalizada(mensaje, null);
    }
     public static final String MENSAJE_ERROR = "Error";
}
