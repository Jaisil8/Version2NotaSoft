package notassoft.capa4_persistencia;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import notassoft.capa3_dominio.Unidad;

public class UnidadMySQL {
    private final AccesoDatos accesoDatos;

    public UnidadMySQL(AccesoDatos accesoDatos) {
        this.accesoDatos = accesoDatos;
    }

    public List<Unidad> obtenerUnidadesPorSemestre(int codSemestre) throws SQLException, ExcepcionPersonalizada {
        List<Unidad> unidades = new ArrayList<>();

        try {
            accesoDatos.abrirConexion();
            String sql = "SELECT codUnidad, nombreUnidad FROM unidad WHERE codSemestre = ?";
            PreparedStatement sentencia = accesoDatos.prepararSentencia(sql);
            sentencia.setInt(1, codSemestre);
            ResultSet resultado = sentencia.executeQuery();

            while (resultado.next()) {
                int codUnidad = resultado.getInt("codUnidad");
                String nombreUnidad = resultado.getString("nombreUnidad");
                Unidad unidad = new Unidad(codUnidad, nombreUnidad);
                unidades.add(unidad);
            }
        } catch (SQLException | ExcepcionPersonalizada e) {
            throw new SQLException("Ocurrió un problema al obtener las unidades", e);
        } finally {
            accesoDatos.cerrarConexion();
        }

        return unidades;
    }
}
