package notassoft.capa4_persistencia;

import java.sql.DriverManager;
import java.sql.SQLException;

public class AccesoDatosMySQL extends AccesoDatos {

    @Override
        public void abrirConexion() throws ExcepcionPersonalizada{
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url = "jdbc:mysql://localhost:3306/notassoft";
                conexion = DriverManager.getConnection(url, "root", "1234");
            } catch (ClassNotFoundException | SQLException e) {
               throw new ExcepcionPersonalizada("Ocuurió un problema en la conexión con la base de datos.", e);
            }
    }

}
