package notassoft.capa2_aplicacion;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import notassoft.capa3_dominio.AsignacionCurso;
import notassoft.capa3_dominio.Curso;
import notassoft.capa3_dominio.Matricula;
import notassoft.capa3_dominio.Notas;
import notassoft.capa3_dominio.Unidad;
import notassoft.capa4_persistencia.AccesoDatos;
import notassoft.capa4_persistencia.AccesoDatosMySQL;
import notassoft.capa4_persistencia.AsignacionCursoMySQL;
import notassoft.capa4_persistencia.CursoMySQL;
import notassoft.capa4_persistencia.MatriculaMySQL;
import notassoft.capa4_persistencia.ExcepcionPersonalizada;
import notassoft.capa4_persistencia.NotasMySQL;
import notassoft.capa4_persistencia.UnidadMySQL;

public class GestionarRegistroNotasServicio implements Serializable {

    private final AccesoDatos accesoDatos;
    private final NotasMySQL notasMySQL;
    private final AsignacionCursoMySQL asignacionCursoMySQL;
    private final MatriculaMySQL matriculaMySQL;
    private final UnidadMySQL unidadMySQL;
    private final CursoMySQL cursoMySQL;

    public GestionarRegistroNotasServicio() {
        accesoDatos = new AccesoDatosMySQL();
        notasMySQL = new NotasMySQL(accesoDatos);
        asignacionCursoMySQL = new AsignacionCursoMySQL(accesoDatos);
        matriculaMySQL = new MatriculaMySQL(accesoDatos);
        unidadMySQL = new UnidadMySQL(accesoDatos);
        cursoMySQL = new CursoMySQL(accesoDatos);
    }

    public AsignacionCurso obtenerAsignacionesPorCursoYSemestre(int codSemestre, int codCurso) throws Exception {
        accesoDatos.abrirConexion();
        AsignacionCurso asignacionCurso = asignacionCursoMySQL.obtenerAsignacionesPorCursoYSemestre(codCurso, codSemestre);
        accesoDatos.cerrarConexion();
        return asignacionCurso;
    }

    public AsignacionCurso obtenerAsignacion(int codAsignacion) throws Exception {
        accesoDatos.abrirConexion();
        AsignacionCurso asignacionCurso = asignacionCursoMySQL.obtenerAsignacion(codAsignacion);
        accesoDatos.cerrarConexion();
        return asignacionCurso;
    }

    public Matricula buscarMatricula(long codAlumno) throws Exception {
        accesoDatos.abrirConexion();
        Matricula matricula = matriculaMySQL.buscarMatricula(codAlumno);
        accesoDatos.cerrarConexion();
        return matricula;
    }

    public Notas actualizarNotas(double notaPractica, double notaProyecto, double notaExamen, int codAsignacion, int idMatricula, int codUnidad) throws Exception {
        accesoDatos.abrirConexion();
        Notas nota = notasMySQL.actualizarNotas(notaPractica, notaProyecto, notaExamen, codAsignacion, idMatricula, codUnidad);
        accesoDatos.cerrarConexion();
        return nota;
    }

    public Notas obtenerNotas(int codAsignacion, int codUnidad) throws SQLException, ExcepcionPersonalizada {
        accesoDatos.abrirConexion();
        Notas nota = (Notas) notasMySQL.obtenerNotas(codAsignacion, codUnidad);
        accesoDatos.cerrarConexion();
        return nota;
    }

    public List<Unidad> obtenerUnidadesPorSemestre(int codSemestre) throws Exception {
        accesoDatos.abrirConexion();
        List<Unidad> unidad = unidadMySQL.obtenerUnidadesPorSemestre(codSemestre);
        accesoDatos.cerrarConexion();
        return unidad;
    }

    public List<Curso> obtenerCursos(String idUsuario, int codSemestre) throws Exception {
        accesoDatos.abrirConexion();
        List<Curso> curso = cursoMySQL.obtenerCursos(idUsuario, codSemestre);
        accesoDatos.cerrarConexion();
        return curso;
    }

}
