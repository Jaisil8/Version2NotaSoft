import notassoft.capa3_dominio.Notas;
import static org.testng.Assert.*;
import org.testng.annotations.Test;

public class NotasNGTest {

    @Test
    public void testValidarNotasEnRango1() {
        System.out.println("Prueba: testValidarNotasEnRango1");

        // Caso de prueba: Todas las notas están dentro del rango válido
        Notas instance = new Notas();
        instance.setNotaPractica(18.5);
        instance.setNotaProyecto(15.0);
        instance.setNotaExamen(13.2);

        boolean expResult = true;
        boolean result = instance.validarNotasEnRango();

        assertEquals(result, expResult, "Las notas están dentro del rango válido");
    }

    @Test
    public void testValidarNotasEnRango2() {
        System.out.println("Prueba: testValidarNotasEnRango2");

        // Caso de prueba: Al menos una nota está fuera del rango válido
        Notas instance = new Notas();
        instance.setNotaPractica(21.0);
        instance.setNotaProyecto(9.2);
        instance.setNotaExamen(7.8);

        boolean expResult = false;
        boolean result = instance.validarNotasEnRango();

        assertEquals(result, expResult, "Al menos una nota está fuera del rango válido");
    }

    @Test
    public void testValidarNumeros() {
        System.out.println("Prueba: testValidarNumeros");

        // Caso de prueba: El texto contiene solo números
        String texto = "12345";
        Notas instance = new Notas();

        boolean expResult = true;
        boolean result = instance.validarNumeros(texto);

        assertEquals(result, expResult, "El texto contiene solo números");
    }

    @Test
    public void testValidarNumerosInvalidos() {
        System.out.println("Prueba: testValidarNumerosInvalidos");

        // Caso de prueba: El texto contiene caracteres no numéricos
        String texto = "abc123";
        Notas instance = new Notas();

        boolean expResult = false;
        boolean result = instance.validarNumeros(texto);

        assertEquals(result, expResult, "El texto contiene caracteres no numéricos");
    }

    @Test
    public void testCalcularPromedio() {
        System.out.println("Prueba: testCalcularPromedio");

        // Caso de prueba: Notas con decimales
        Notas instance = new Notas();
        instance.setNotaPractica(18.5);
        instance.setNotaProyecto(15.0);
        instance.setNotaExamen(13.2);

        double expResult = 15.9;
        double result = instance.calcularPromedio();

        assertEquals(result, expResult, 0.1, "El promedio es calculado correctamente");
    }

    @Test
    public void testCalcularPromedioNotasEnteras() {
        System.out.println("Prueba: testCalcularPromedioNotasEnteras");

        // Caso de prueba: Notas enteras
        Notas instance = new Notas();
        instance.setNotaPractica(20.0);
        instance.setNotaProyecto(18.0);
        instance.setNotaExamen(16.0);

        double expResult = 18.0;
        double result = instance.calcularPromedio();

        assertEquals(result, expResult, 0.1, "El promedio es calculado correctamente");
    }
}
